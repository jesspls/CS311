

public class SinglyNode<E>
{
	E data;
	SinglyNode<E> next;
	
	public SinglyNode(E data)
	{
		this.data = data;
		next = null;
	}
}
